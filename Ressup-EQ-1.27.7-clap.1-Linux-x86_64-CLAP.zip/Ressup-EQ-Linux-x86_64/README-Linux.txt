Ressup-EQ 1.27.7-clap.1 -- Linux x86-64 CLAP

Installation
1. Close the DAW.
2. Copy Ressup-EQ.clap to ~/.clap/ (create the directory if necessary).
3. Reopen the DAW and rescan CLAP plugins.

The plugin is called Ressup-EQ, manufacturer Valla Productions.
This is a native Linux x86-64 binary with the original custom editor.
It does not require Wine, a Windows bridge, JUCE or the VST3 SDK to be installed.

Requirements
- Linux x86-64 with glibc 2.35 or newer (Ubuntu 22.04 or newer).
- A CLAP-compatible Linux DAW and an X11 display or XWayland.
- The usual desktop libraries: fontconfig, FreeType, X11, Xcursor, Xext,
  Xinerama, Xrandr, Xrender, Xcomposite and Xi.
- Native Wayland-surface embedding and ARM64 binaries are not included.

Keep the accompanying licenses with the plugin package.
The original software is subject to the license in licenses/LICENSE.
See manifest.json for the exact binary checksum and validation information.
